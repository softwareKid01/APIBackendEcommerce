﻿using Microsoft.EntityFrameworkCore;
using RestoreEcommerce.Entities;
using System.Security.Principal;

namespace RestoreEcommerce.Data
{
    public class StoreContext : DbContext
    {
        public StoreContext(DbContextOptions options) : base(options)
        {
        }

        public DbSet<Product> Products { get; set; }
    }
}
